#!/usr/bin/env bash
# Сборка APK: Rust-ядро (libmajestic.so, arm64) + Java-оболочка + HTML из assets/.
#
#   MAJESTIC_API_KEY=ваш_ключ ./scripts/build.sh
#
# Нужно:
#   - Rust (rustup) с целью aarch64-linux-android (скрипт добавит её сам)
#   - Android NDK (ANDROID_NDK_HOME или самый новый в $ANDROID_HOME/ndk)
#   - Android SDK: build-tools и platforms/android-30 (android.jar)
#   - JDK 17
# Переменные: ANDROID_HOME, ANDROID_NDK_HOME, BUILD_TOOLS, PLATFORM_JAR,
#             NATIVE_LIB (готовый .so — тогда cargo не запускается; для проверки упаковки).
set -euo pipefail
cd "$(dirname "$0")/.."

: "${MAJESTIC_API_KEY:?Задайте ключ: MAJESTIC_API_KEY=... ./scripts/build.sh}"

MIN_SDK=23
TARGET_SDK=30
ABI=arm64-v8a
TRIPLE=aarch64-linux-android
KS_PASS=android
KS_ALIAS=majestic

ANDROID_HOME="${ANDROID_HOME:-$HOME/Android/Sdk}"
latest() { ls -d "$1"/* 2>/dev/null | sort -V | tail -1 || true; }
NDK="${ANDROID_NDK_HOME:-$(latest "$ANDROID_HOME/ndk")}"
BT="${BUILD_TOOLS:-$(latest "$ANDROID_HOME/build-tools")}"
PLATFORM="${PLATFORM_JAR:-$ANDROID_HOME/platforms/android-$TARGET_SDK/android.jar}"

tool() { if [ -x "$BT/$1" ]; then echo "$BT/$1"; else command -v "$1"; fi; }
AAPT=$(tool aapt); ZIPALIGN=$(tool zipalign); APKSIGNER=$(tool apksigner)

rm -rf build && mkdir -p build/classes build/dex build/apk/lib/$ABI

# 1. Rust-ядро
if [ -n "${NATIVE_LIB:-}" ]; then
  echo "[1/6] используем готовый $NATIVE_LIB"
  cp "$NATIVE_LIB" build/apk/lib/$ABI/libmajestic.so
else
  [ -d "$NDK" ] || { echo "Не найден Android NDK. Задайте ANDROID_NDK_HOME."; exit 1; }
  echo "[1/6] сборка Rust-ядра"
  rustup target add $TRIPLE >/dev/null
  TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
  export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$TC/aarch64-linux-android$MIN_SDK-clang"
  export CC_aarch64_linux_android="$TC/aarch64-linux-android$MIN_SDK-clang"
  export AR_aarch64_linux_android="$TC/llvm-ar"
  touch src/api.rs   # пересобрать, если ключ поменялся
  cargo build --release --lib --target $TRIPLE
  cp target/$TRIPLE/release/libmajestic.so build/apk/lib/$ABI/libmajestic.so
fi

# 2. Java-оболочка
echo "[2/6] компиляция Java"
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLATFORM" -Xlint:-options \
  -d build/classes $(find android/src -name '*.java')

# 3. dex
echo "[3/6] dex"
CLASSES=$(find build/classes -name '*.class')
if [ -x "$BT/d8" ]; then
  "$BT/d8" --release --min-api $MIN_SDK --lib "$PLATFORM" --output build/dex $CLASSES
else
  dalvik-exchange --dex --output=build/dex/classes.dex build/classes
fi

# 4. упаковка: манифест, интерфейс из assets/, dex, нативная библиотека
echo "[4/6] упаковка APK"
"$AAPT" package -f -M android/AndroidManifest.xml -A assets -I "$PLATFORM" \
  --min-sdk-version $MIN_SDK --target-sdk-version $TARGET_SDK -F build/app.unsigned.apk
(cd build/dex && "$AAPT" add ../app.unsigned.apk classes.dex >/dev/null)
(cd build/apk && "$AAPT" add ../app.unsigned.apk lib/$ABI/libmajestic.so >/dev/null)

# 5. выравнивание
echo "[5/6] выравнивание"
"$ZIPALIGN" -f -p 4 build/app.unsigned.apk build/app.aligned.apk

# 6. подпись (отладочный ключ создаётся один раз; храните его: без него обновление не поставится поверх)
echo "[6/6] подпись"
if [ ! -f majestic-debug.jks ]; then
  keytool -genkeypair -keystore majestic-debug.jks -storepass $KS_PASS -keypass $KS_PASS \
    -alias $KS_ALIAS -keyalg RSA -keysize 2048 -validity 20000 -dname "CN=Majestic" >/dev/null
fi
mkdir -p dist
"$APKSIGNER" sign --ks majestic-debug.jks --ks-pass pass:$KS_PASS --key-pass pass:$KS_PASS \
  --ks-key-alias $KS_ALIAS --out dist/majestic.apk build/app.aligned.apk
"$APKSIGNER" verify --min-sdk-version $MIN_SDK dist/majestic.apk >/dev/null && echo "подпись проверена"
echo "Готово: dist/majestic.apk"
