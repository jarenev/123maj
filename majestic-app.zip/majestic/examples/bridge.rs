//! Утилита для тестов: `bridge '<json-запрос>'` -> печатает ответ ядра.
//! База API берётся из MAJESTIC_TEST_BASE (по умолчанию — боевой адрес).

fn main() {
    let base = std::env::var("MAJESTIC_TEST_BASE")
        .unwrap_or_else(|_| majestic::api::BASE_URL.to_string());
    let key = std::env::var("MAJESTIC_TEST_KEY").unwrap_or_else(|_| "TESTKEY".to_string());
    let req = std::env::args().nth(1).unwrap_or_default();
    let client = majestic::api::Client::new(&base, &key);
    println!("{}", majestic::ops::handle(&client, &req));
}
