use majestic::api::Client;
use majestic::ops::{captures_data, compare_data, handle, market_data, rating_data, wars_data};
use serde_json::{json, Value};
use std::io::{Read, Write};
use std::net::TcpListener;

fn v(s: &str) -> Value {
    serde_json::from_str(s).expect("fixture json")
}

const VEHICLES: &str = r##"{
  "serverId": "RU1", "serverName": "New York", "lastUpdated": "2026-05-16T12:00:00.000Z", "periodDays": 7,
  "vehicleStatistics": [
    {"model": "sultan", "modelName": "Karin Sultan", "totalCount": 124, "soldCount": 18, "averagePrice": 250000, "minPrice": 180000, "maxPrice": 320000},
    {"model": "sultan", "modelName": "Karin Sultan", "totalCount": 10, "soldCount": 2, "averagePrice": 200000, "minPrice": 150000, "maxPrice": 210000}
  ],
  "totalVehicles": 134, "totalSold": 20, "overallAveragePrice": 240000
}"##;

const WARS: &str = r##"{
  "serverId": "RU1", "serverName": "New York",
  "captures": [
    {"id": 9001, "captureId": 5001, "defendersId": 101, "attackersId": 202,
     "defendersName": "Los Santos Vagos", "attackersName": "Ballas", "gangZoneId": 42, "winner": 202,
     "selectedMapName": "Rebl Construction Site", "startAt": "2026-05-16T18:00:00.000Z", "endAt": "2026-05-16T18:45:00.000Z",
     "uniqueDefenders": 12, "uniqueAttackers": 15, "attackerRating": 1250, "defenderRating": 1180, "status": "finished",
     "players": {"101": [{"id": 10001, "name": "player_one", "familyId": 101, "familyName": "Los Santos Vagos", "damage": 4200, "kills": 3}],
                 "202": [{"id": 20002, "name": "player_two", "familyId": 202, "familyName": "Ballas", "damage": 5100, "kills": 5}]}},
    {"id": 9002, "captureId": 5002, "defendersId": 303, "attackersId": 101, "defendersName": "Families", "attackersName": "Los Santos Vagos",
     "gangZoneId": 7, "winner": 303, "selectedMapName": "Docks", "startAt": "2026-05-17T10:00:00.000Z", "endAt": "2026-05-17T10:40:00.000Z",
     "status": "finished", "players": {}}
  ]
}"##;

#[test]
fn market_normalizes_shape_and_keeps_rows() {
    let d = market_data("vehicles", &v(VEHICLES));
    assert_eq!(d["serverName"], "New York");
    assert_eq!(d["rows"].as_array().unwrap().len(), 2);
    assert_eq!(d["rows"][0]["name"], "Karin Sultan");
    assert_eq!(d["rows"][0]["sub"], "sultan");
    assert_eq!(d["rows"][0]["avg"], 250000);
}

#[test]
fn compare_weights_average_by_sold_and_gives_verdict() {
    let m = market_data("vehicles", &v(VEHICLES));
    // средняя взвешенная: (250000*18 + 200000*2) / 20 = 245000
    let c = compare_data(&m, "karin sultan", Some(200000.0));
    assert_eq!(c["found"], true);
    assert_eq!(c["summary"]["avg"], 245000.0);
    assert_eq!(c["summary"]["min"], 150000.0);
    assert_eq!(c["summary"]["max"], 320000.0);
    assert_eq!(c["verdict"]["position"], "below_avg");
    assert!((c["verdict"]["percent"].as_f64().unwrap() - 18.4).abs() < 0.05);

    let high = compare_data(&m, "Karin Sultan", Some(400000.0));
    assert_eq!(high["verdict"]["position"], "above_max");

    let none = compare_data(&m, "несуществующая", Some(1.0));
    assert_eq!(none["found"], false);
}

#[test]
fn compare_falls_back_to_substring_match() {
    let m = market_data("vehicles", &v(VEHICLES));
    let c = compare_data(&m, "sultan", None);
    assert_eq!(c["found"], true);
    assert_eq!(c["verdict"], Value::Null);
}

#[test]
fn captures_convert_seconds_to_ms_and_skip_free_zones() {
    let body = v(r##"{"serverName":"New York","zones":[
        {"zoneId":42,"familyId":101,"familyName":"Los Santos Vagos","familyTag":"LSV","familyMainColor":"#FF5733","controlStartTime":1715000000},
        {"zoneId":43,"familyId":null,"familyName":null,"familyTag":null,"familyMainColor":null,"controlStartTime":null}]}"##);
    let d = captures_data(&body);
    assert_eq!(d["zones"][0]["sinceMs"], 1715000000000.0);
    assert_eq!(d["zones"][1]["sinceMs"], Value::Null);
    assert_eq!(d["zones"][0]["color"], "#FF5733");
}

#[test]
fn wars_filter_by_either_side_and_resolve_winner() {
    let body = v(WARS);
    let all = wars_data(&body, "");
    assert_eq!(all["count"], 2);
    // свежая первой
    assert_eq!(all["wars"][0]["map"], "Docks");

    let ballas = wars_data(&body, "ballas");
    assert_eq!(ballas["count"], 1);
    let w = &ballas["wars"][0];
    assert_eq!(w["winner"], "attack");
    assert_eq!(w["defender"]["name"], "Los Santos Vagos");

    // фильтр по «Los Santos» находит обе войны (в одной защитник, в другой нападающий)
    let lsv = wars_data(&body, "los santos");
    assert_eq!(lsv["count"], 2);
    // игроки сортируются по урону, сторона определяется по ключу
    let players = &ballas["wars"][0]["players"];
    assert_eq!(players[0]["name"], "player_two");
    assert_eq!(players[0]["side"], "attack");
    assert_eq!(players[1]["side"], "defense");
}

#[test]
fn rating_sorts_and_computes_change_and_parses_influence() {
    let body = v(r##"{"serverName":"New York","organizations":[
        {"rank":2,"familyId":5,"name":"B","tag":"BBB","prevRank":1,"influence":"9000","mainColor":"#fff","logoStatus":0,"logoType":"png"},
        {"rank":1,"familyId":101,"name":"Los Santos Vagos","tag":"LSV","prevRank":2,"influence":"12500","mainColor":"#FF5733","logoStatus":1,"logoType":"png"},
        {"rank":3,"familyId":7,"name":"C","tag":"CCC","prevRank":null,"influence":"100"}]}"##);
    let d = rating_data(&body);
    let o = d["organizations"].as_array().unwrap();
    assert_eq!(o[0]["name"], "Los Santos Vagos");
    assert_eq!(o[0]["change"], 1.0);     // поднялась на 1
    assert_eq!(o[1]["change"], -1.0);    // опустилась на 1
    assert_eq!(o[0]["influence"], 12500.0);
    assert_eq!(o[2]["change"], Value::Null);
}

#[test]
fn handle_rejects_bad_input_without_network() {
    let c = Client::new("http://127.0.0.1:9", "KEY");
    let bad_server = handle(&c, r##"{"action":"captures","server":"../etc"}"##);
    assert!(bad_server.contains("\"ok\":false"));
    let bad_kind = handle(&c, r##"{"action":"marketplace","server":"RU1","kind":"x; drop"}"##);
    assert!(bad_kind.contains("Неизвестный раздел"));
    let bad_period = handle(&c, r##"{"action":"rating","server":"RU1","period":"day"}"##);
    assert!(bad_period.contains("Неизвестный период"));
    let bad_price = handle(&c, r##"{"action":"compare","kind":"items","name":"ID card","price":"-5"}"##);
    assert!(bad_price.contains("неотрицательным"));
    let garbage = handle(&c, "not json");
    assert!(garbage.contains("Некорректный запрос"));
}

/// Мок-сервер: принимает ровно одно соединение, проверяет заголовки и отдаёт JSON.
#[test]
fn http_sends_key_and_second_call_uses_cache() {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let addr = listener.local_addr().unwrap();
    let server = std::thread::spawn(move || {
        let (mut s, _) = listener.accept().unwrap();
        let mut buf = [0u8; 4096];
        let n = s.read(&mut buf).unwrap();
        let req = String::from_utf8_lossy(&buf[..n]).to_string();
        assert!(req.starts_with("GET /v1/ext/captures/RU1 "), "путь: {req}");
        assert!(req.to_lowercase().contains("x-api-key: test-key"), "нет заголовка ключа");
        assert!(req.to_lowercase().contains("x-language: ru"));
        let body = r##"{"serverName":"New York","zones":[]}"##;
        let resp = format!(
            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            body.len(), body
        );
        s.write_all(resp.as_bytes()).unwrap();
    });

    let c = Client::new(&format!("http://{addr}"), "test-key");
    let first = handle(&c, r##"{"action":"captures","server":"RU1"}"##);
    assert!(first.contains("\"ok\":true"), "{first}");
    // второй вызов — из кэша, сервер больше не принимает соединений
    let second = handle(&c, r##"{"action":"captures","server":"RU1"}"##);
    assert_eq!(first, second);
    server.join().unwrap();
    let _ = json!({});
}

#[test]
fn no_key_is_reported_clearly() {
    let c = Client::new("http://127.0.0.1:9", "");
    let r = handle(&c, r##"{"action":"captures","server":"RU1"}"##);
    assert!(r.contains("не вшит в сборку"));
}
