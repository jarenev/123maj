import subprocess, time, sys, os, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parents[2]
SHOTS = ROOT / "tests" / "e2e" / "shots"; SHOTS.mkdir(exist_ok=True)
procs = [
  subprocess.Popen([sys.executable, str(ROOT/"tests/e2e/mock_api.py"), "8766"]),
  subprocess.Popen([sys.executable, str(ROOT/"tests/e2e/bridge_server.py"), "8765", str(ROOT/"target/debug/examples/bridge")]),
  subprocess.Popen([sys.executable, "-m", "http.server", "8767", "--bind", "127.0.0.1", "--directory", str(ROOT/"assets")],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
]
time.sleep(1.5)
MOCK = """
window.Android = { call(id, json) {
  fetch('http://127.0.0.1:8765/core', {method:'POST', headers:{'Content-Type':'text/plain'}, body: json})
    .then(r => r.text()).then(t => window.__resolve(id, t))
    .catch(e => window.__resolve(id, JSON.stringify({ok:false, error:'мост: ' + e})));
}};
"""
errors = []
try:
  with sync_playwright() as p:
    b = p.chromium.launch()
    for name, vp, ua in [("phone", {"width":390,"height":780}, "Mozilla/5.0 (Linux; Android 13) Mobile Wibble"),
                         ("desktop", {"width":1100,"height":820}, "Mozilla/5.0 (X11; Linux x86_64) Chrome")]:
      ctx = b.new_context(viewport=vp, user_agent=ua, has_touch=False)
      ctx.add_init_script(MOCK)
      page = ctx.new_page()
      page.on("pageerror", lambda e: errors.append(f"{name} pageerror: {e}"))
      page.on("console", lambda m: errors.append(f"{name} console: {m.text}") if m.type == "error" else None)
      page.goto("http://127.0.0.1:8767/index.html")

      # --- рынок ---
      page.wait_for_selector("#m-list .row")
      assert page.locator("#m-list .row").count() == 2, "в списке должно быть 2 предмета"
      page.fill("#m-name", "id card")
      page.fill("#m-price", "200 000")
      page.click("#m-go")
      page.wait_for_selector(".verdict")
      verdict = page.inner_text(".verdict")
      assert "ниже средней" in verdict, verdict
      stats = page.inner_text(".stats")
      assert "250 000" in stats and "180 000" in stats, stats
      if name == "desktop":
        page.screenshot(path=str(SHOTS/"market_compare.png"), full_page=False)
        print("market verdict:", verdict.replace("\n", " | "))

      page.fill("#m-name", "")
      page.fill("#m-price", "")
      page.click("#kinds [data-kind=vehicles]")
      page.wait_for_selector("#m-list .row")
      assert "Karin Sultan" in page.inner_text("#m-list")

      # --- капты ---
      page.click(".tab[data-tab=captures]")
      page.wait_for_selector("#c-list .row")
      page.fill("#c-family", "ballas")
      page.click("#c-go")
      page.wait_for_selector("#c-owned .row, #c-owned .empty")
      assert page.locator("#c-list .row").count() == 1, "у Ballas одна война"
      owned = page.inner_text("#c-owned")
      assert "Зона 43" in owned, owned
      page.click("#c-list [data-war='0']")
      page.wait_for_selector("[data-players='0']:not([hidden])")
      players = page.inner_text("[data-players='0']")
      assert "player_two" in players and "нападение" in players, players
      if name == "desktop":
        page.screenshot(path=str(SHOTS/"captures_history.png"))
      page.click("#c-all")
      page.wait_for_function("document.querySelectorAll('#c-list .row').length === 2")

      # --- рейтинг ---
      page.click(".tab[data-tab=rating]")
      page.wait_for_selector("#r-list .row")
      rows = page.inner_text("#r-list")
      assert "Los Santos Vagos" in rows and "▲ 1" in rows and "▼ 2" in rows, rows
      if name == "phone":
        page.screenshot(path=str(SHOTS/"phone_rating.png"))
      page.click("#periods [data-period=week]")
      page.wait_for_function("document.querySelectorAll('#r-list .row').length === 1")
      page.fill("#r-filter", "bal")
      assert page.locator("#r-list .row").count() == 1
      if name == "desktop":
        page.fill("#r-filter", "")
        page.click("#periods [data-period='']")
        page.wait_for_selector("#r-list .row:nth-child(3)")
        page.screenshot(path=str(SHOTS/"rating.png"))
      ctx.close()
      print(f"{name}: OK")
    b.close()
finally:
  for pr in procs: pr.terminate()
print("errors:", errors if errors else "none")
