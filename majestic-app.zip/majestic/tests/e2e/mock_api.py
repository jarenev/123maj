"""Мок api.majestic-files.net: отдаёт фикстуры в формате из документации, проверяет X-API-KEY."""
import json, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

FIX = {
  "/v1/ext/marketplace/items/RU1": {"serverId":"RU1","serverName":"New York","lastUpdated":"2026-05-16T12:00:00.000Z","periodDays":7,
    "itemStatistics":[
      {"itemId":101,"itemName":"ID card","totalCount":50,"soldCount":18,"averagePrice":250000,"minPrice":180000,"maxPrice":320000},
      {"itemId":102,"itemName":"Phone","totalCount":30,"soldCount":9,"averagePrice":12000,"minPrice":9000,"maxPrice":15000}],
    "totalItems":80,"totalSold":27,"overallAveragePrice":200000},
  "/v1/ext/marketplace/vehicles/RU1": {"serverId":"RU1","serverName":"New York","lastUpdated":"2026-05-16T12:00:00.000Z","periodDays":7,
    "vehicleStatistics":[{"model":"sultan","modelName":"Karin Sultan","totalCount":124,"soldCount":18,"averagePrice":250000,"minPrice":180000,"maxPrice":320000}],
    "totalVehicles":124,"totalSold":18,"overallAveragePrice":250000},
  "/v1/ext/captures/RU1": {"serverId":"RU1","serverName":"New York","lastUpdated":"2026-05-16T12:00:00.000Z","zones":[
      {"zoneId":42,"familyId":101,"familyName":"Los Santos Vagos","familyTag":"LSV","familyMainColor":"#FF5733","controlStartTime":1715000000},
      {"zoneId":43,"familyId":202,"familyName":"Ballas","familyTag":"BLS","familyMainColor":"#000","controlStartTime":1716000000},
      {"zoneId":44,"familyId":None,"familyName":None,"familyTag":None,"familyMainColor":None,"controlStartTime":None}]},
  "/v1/ext/family-wars/RU1": {"serverId":"RU1","serverName":"New York","captures":[
      {"id":9001,"captureId":5001,"defendersId":101,"attackersId":202,"defendersName":"Los Santos Vagos","attackersName":"Ballas",
       "gangZoneId":42,"winner":202,"selectedMapName":"Rebl Construction Site","startAt":"2026-05-16T18:00:00.000Z","endAt":"2026-05-16T18:45:00.000Z",
       "uniqueDefenders":12,"uniqueAttackers":15,"attackerRating":1250,"defenderRating":1180,"status":"finished",
       "players":{"101":[{"id":10001,"name":"player_one","familyId":101,"familyName":"Los Santos Vagos","damage":4200,"kills":3}],
                  "202":[{"id":20002,"name":"player_two","familyId":202,"familyName":"Ballas","damage":5100,"kills":5}]}},
      {"id":9002,"captureId":5002,"defendersId":303,"attackersId":101,"defendersName":"Families","attackersName":"Los Santos Vagos",
       "gangZoneId":7,"winner":303,"selectedMapName":"Docks","startAt":"2026-05-17T10:00:00.000Z","endAt":"2026-05-17T10:40:00.000Z","status":"finished","players":{}}]},
  "/v1/ext/rating-organizations/RU1": {"serverId":"RU1","serverName":"New York","organizations":[
      {"rank":2,"familyId":202,"name":"Ballas","tag":"BLS","prevRank":3,"influence":"9000","mainColor":"#000","logoStatus":0,"logoType":"png"},
      {"rank":1,"familyId":101,"name":"Los Santos Vagos","tag":"LSV","prevRank":2,"influence":"12500","mainColor":"#FF5733","logoStatus":1,"logoType":"png"},
      {"rank":3,"familyId":7,"name":"Families","tag":"FAM","prevRank":1,"influence":"4100"}]},
  "/v1/ext/rating-organizations/RU1?period=week": {"serverId":"RU1","serverName":"New York","organizations":[
      {"rank":1,"familyId":202,"name":"Ballas","tag":"BLS","prevRank":1,"influence":"777","mainColor":"#000"}]},
}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        path = self.path
        if self.headers.get("X-API-KEY") != "TESTKEY":
            return self._send(401, {"error": "UNAUTHORIZED"})
        if self.headers.get("X-LANGUAGE") != "ru":
            return self._send(400, {"error": "LANG"})
        if path in FIX:
            return self._send(200, FIX[path])
        return self._send(404, {"error": "NOT_FOUND"})

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
