"""Прокси: POST /core (тело = JSON-запрос) -> запускает Rust-бинарник bridge и возвращает ответ ядра."""
import subprocess, sys, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BIN = sys.argv[2]
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_OPTIONS(self):
        self.send_response(204); self._cors(); self.end_headers()
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        req = self.rfile.read(n).decode()
        env = dict(os.environ, MAJESTIC_TEST_BASE="http://127.0.0.1:8766", MAJESTIC_TEST_KEY="TESTKEY")
        out = subprocess.run([BIN, req], capture_output=True, text=True, env=env, timeout=120).stdout.strip()
        body = out.encode()
        self.send_response(200); self._cors()
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers(); self.wfile.write(body)

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
