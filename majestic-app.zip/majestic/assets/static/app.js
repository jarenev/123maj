(() => {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const html = document.documentElement;
  html.classList.add(/Android/i.test(navigator.userAgent) ? 'android' : 'desktop');

  // ---------- мост к Rust-ядру ----------
  // Android.call(id, json) -> ядро -> window.__resolve(id, json)
  const waiting = new Map();
  let seq = 0;

  window.__resolve = (id, text) => {
    const done = waiting.get(id);
    if (!done) return;
    waiting.delete(id);
    let res;
    try { res = JSON.parse(text); }
    catch (e) { res = { ok: false, error: 'Ядро вернуло некорректный ответ' }; }
    done(res);
  };

  function core(req) {
    return new Promise((resolve) => {
      if (!window.Android || typeof window.Android.call !== 'function') {
        resolve({ ok: false, error: 'Ядро недоступно: откройте приложение в Android' });
        return;
      }
      const id = String(++seq);
      waiting.set(id, resolve);
      window.Android.call(id, JSON.stringify(req));
    });
  }

  // ---------- утилиты ----------
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = (n) => (typeof n === 'number' && isFinite(n))
    ? Math.round(n).toLocaleString('ru-RU').replace(/\u00a0/g, ' ') : '—';
  const dt = (s) => {
    if (!s) return '—';
    const d = new Date(s);
    if (isNaN(d)) return '—';
    return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };
  const server = () => ($('#server').value.trim().toUpperCase() || 'RU1');
  const MARKET_KINDS = [
    ['items', 'Предметы'], ['vehicles', 'Транспорт'], ['clothes', 'Одежда'], ['houses', 'Дома'],
    ['apartments', 'Квартиры'], ['warehouses', 'Склады'], ['offices', 'Офисы'],
  ];
  const RATING_PERIODS = [['', 'по умолчанию'], ['week', 'week'], ['period', 'period'], ['season', 'season']];

  const state = {
    tab: 'market',
    kind: 'items',
    market: null,        // ответ marketplace
    wars: [],            // список войн для текущего фильтра
    warsShown: 100,
    warsFamily: null,
    rating: [],
    period: '',
    loaded: { market: false, captures: false, rating: false },
  };

  // ---------- статус ----------
  let statusTimer = 0;
  function busy(on) {
    const el = $('#status');
    el.classList.toggle('busy', on);
    el.innerHTML = on
      ? '<span class="thinking"><span class="dots"><span></span><span></span><span></span></span>загрузка…</span>'
      : el.innerHTML;
  }
  function flash(msg, bad) {
    const el = $('#status');
    el.classList.toggle('busy', false);
    el.className = 'status' + (bad ? ' bad' : '');
    el.textContent = msg || '';
    clearTimeout(statusTimer);
    if (msg && !bad) statusTimer = setTimeout(() => { el.textContent = ''; }, 4000);
  }
  function fail(res) { flash(res.error || 'Не удалось получить данные', true); }

  // ---------- маркетплейс ----------
  function renderKinds() {
    $('#kinds').innerHTML = MARKET_KINDS.map(([k, label]) =>
      `<button class="chip${k === state.kind ? ' on' : ''}" type="button" data-kind="${k}">${label}</button>`).join('');
  }

  async function loadMarket(force) {
    busy(true);
    const res = await core({ action: 'marketplace', server: server(), kind: state.kind, force: !!force });
    if (!res.ok) return fail(res);
    busy(false); flash('');
    state.market = res.data;
    state.loaded.market = true;
    $('#m-meta').textContent = `${res.data.serverName || ''} · данные за ${res.data.periodDays ?? '—'} дн. · обновлено ${dt(res.data.lastUpdated)}`;
    renderList();
    if ($('#m-name').value.trim()) compare();
  }

  function renderList() {
    const rows = state.market?.rows || [];
    const q = $('#m-name').value.trim().toLowerCase();
    const shown = rows.filter((r) => !q || String(r.name).toLowerCase().includes(q) || String(r.sub || '').toLowerCase().includes(q));
    $('#m-cnt').textContent = `${shown.length} из ${rows.length}`;
    $('#m-list').innerHTML = shown.slice(0, 300).map((r) =>
      `<button class="row" type="button" data-name="${esc(r.name)}">
         <span class="main"><span class="name">${esc(r.name)}</span>
           <span class="sub">${r.sub ? esc(r.sub) + ' · ' : ''}продано ${num(r.sold)}</span></span>
         <span class="val">${num(r.avg)}<small>мин ${num(r.min)}</small></span>
       </button>`).join('') || '<p class="empty">Ничего не найдено. Попробуйте другое название или раздел.</p>';
  }

  async function compare() {
    const name = $('#m-name').value.trim();
    if (!name) { $('#m-result').innerHTML = ''; return; }
    const price = $('#m-price').value.trim();
    const res = await core({ action: 'compare', server: server(), kind: state.kind, name, price: price || null });
    if (!res.ok) return fail(res);
    renderCompare(res.data);
  }

  function renderCompare(d) {
    if (!d.found) {
      $('#m-result').innerHTML = '<p class="empty">Такого предмета нет в статистике этого раздела. Попробуйте часть названия.</p>';
      return;
    }
    const s = d.summary;
    const v = d.verdict;
    let verdict;
    if (!v) {
      verdict = '<div class="verdict none">Введите свою цену, чтобы сравнить её с рынком</div>';
    } else {
      const text = {
        below_min: ['Ниже минимальной цены на рынке', ''],
        above_max: ['Выше максимальной цены на рынке', ''],
        below_avg: [`На ${v.percent}% ниже средней цены`, ''],
        above_avg: [`На ${v.percent}% выше средней цены`, ''],
      }[v.position];
      verdict = `<div class="verdict">${esc(text[0])}<small>ваша цена ${num(v.price)} · средняя ${num(s.avg)}</small></div>`;
    }
    const variants = d.matches.length > 1
      ? `<div class="sect"><span>ВАРИАНТЫ</span><span class="cnt">${d.matches.length}</span></div>` +
        d.matches.map((r) => `<div class="row"><span class="main"><span class="name">${esc(r.name)}</span>
           <span class="sub">${r.sub ? esc(r.sub) + ' · ' : ''}продано ${num(r.sold)}</span></span>
           <span class="val">${num(r.avg)}<small>мин ${num(r.min)} · макс ${num(r.max)}</small></span></div>`).join('')
      : '';
    $('#m-result').innerHTML = `
      <h2 class="title">${esc(s.name)}</h2>
      <div class="stats">
        <div><b>${num(s.sold)}</b><span>продано</span></div>
        <div><b>${num(s.avg)}</b><span>средняя</span></div>
        <div><b>${num(s.min)}</b><span>мин</span></div>
        <div><b>${num(s.max)}</b><span>макс</span></div>
      </div>
      ${verdict}
      ${variants}`;
  }

  // ---------- капты и войны ----------
  async function loadCaptures(force) {
    const family = $('#c-family').value.trim();
    busy(true);
    const [zones, wars] = await Promise.all([
      core({ action: 'captures', server: server(), force: !!force }),
      core({ action: 'wars', server: server(), family, force: !!force }),
    ]);
    if (!wars.ok) return fail(wars);
    busy(false); flash('');
    state.loaded.captures = true;
    state.wars = wars.data.wars;
    state.warsShown = 100;
    state.warsFamily = family;

    // текущие владельцы: только когда ищем конкретную фаму
    let ownedHtml = '';
    if (family) {
      if (!zones.ok) {
        ownedHtml = `<p class="empty">Текущие владельцы не загружены: ${esc(zones.error)}</p>`;
      } else {
        const low = family.toLowerCase();
        const owned = zones.data.zones.filter((z) => z.family && z.family.toLowerCase().includes(low));
        ownedHtml = owned.length
          ? `<div class="sect"><span>СЕЙЧАС ВЛАДЕЕТ</span><span class="cnt">${owned.length}</span></div>
             <div class="owned">${owned.map((z) => `<div class="row"><span class="main"><span class="name">Зона ${num(z.zoneId)} · ${esc(z.family)}${z.tag ? `<span class="tagw">${esc(z.tag)}</span>` : ''}</span>
               <span class="sub">с ${dt(z.sinceMs)}</span></span></div>`).join('')}</div>`
          : '<p class="empty">Сейчас эта фама не владеет каптами.</p>';
      }
    }
    $('#c-owned').innerHTML = ownedHtml;

    $('#c-cnt').textContent = `${wars.data.count}`;
    $('#c-meta').textContent = family
      ? `Войны, где фама «${family}» защищалась или нападала`
      : `Все войны за капты · ${wars.data.serverName || server()}`;
    renderWars();
  }

  function renderWars() {
    const list = state.wars.slice(0, state.warsShown);
    $('#c-list').innerHTML = list.map((w, i) => {
      const winName = w.winner === 'attack' ? w.attacker.name : w.winner === 'defense' ? w.defender.name : '';
      return `<button class="row" type="button" data-war="${i}">
        <span class="main"><span class="name">${esc(w.defender.name || '—')} <span class="vs">vs</span> ${esc(w.attacker.name || '—')}</span>
          <span class="sub">${dt(w.startAt)} · ${esc(w.map || '—')}</span></span>
        <span class="val">${esc(winName || '—')}<small>победа</small></span>
      </button><div class="players" data-players="${i}" hidden></div>`;
    }).join('') || '<p class="empty">Войн не найдено.</p>';
    const rest = state.wars.length - list.length;
    $('#c-more').innerHTML = rest > 0
      ? `<button class="more" type="button" id="c-more-btn">Показать ещё ${Math.min(rest, 100)}</button>` : '';
  }

  function togglePlayers(i) {
    const box = document.querySelector(`[data-players="${i}"]`);
    if (!box) return;
    if (!box.hidden) { box.hidden = true; return; }
    const w = state.wars[i];
    const side = { attack: 'нападение', defense: 'защита', unknown: '—' };
    box.innerHTML = w.players.length
      ? w.players.map((p) => `<div class="p"><span><b>${esc(p.name || '—')}</b> ${esc(p.family || '')} · ${side[p.side] || '—'}</span>
          <span>${num(p.kills)} уб · ${num(p.damage)} урон</span></div>`).join('')
      : '<div class="p"><span>Нет данных об игроках</span></div>';
    box.hidden = false;
  }

  // ---------- рейтинг ----------
  function renderPeriods() {
    $('#periods').innerHTML = RATING_PERIODS.map(([v, label]) =>
      `<button class="chip${v === state.period ? ' on' : ''}" type="button" data-period="${v}">${label}</button>`).join('');
  }

  async function loadRating(force) {
    busy(true);
    const res = await core({ action: 'rating', server: server(), period: state.period, force: !!force });
    if (!res.ok) return fail(res);
    busy(false); flash('');
    state.loaded.rating = true;
    state.rating = res.data.organizations;
    $('#r-meta').textContent = `${res.data.serverName || server()} · ▲ поднялась · ▼ опустилась`;
    renderRating();
  }

  function renderRating() {
    const q = $('#r-filter').value.trim().toLowerCase();
    const rows = state.rating.filter((o) => !q || String(o.name || '').toLowerCase().includes(q) || String(o.tag || '').toLowerCase().includes(q));
    $('#r-cnt').textContent = `${rows.length}`;
    $('#r-list').innerHTML = rows.map((o) => {
      const c = o.change;
      const chg = c === null || c === undefined ? '—' : c > 0 ? `▲ ${c}` : c < 0 ? `▼ ${-c}` : '=';
      return `<div class="row org">
        <span class="rank">${num(o.rank)}</span>
        <span class="main"><span class="name">${esc(o.name || '—')}${o.tag ? `<span class="tagw">${esc(o.tag)}</span>` : ''}</span>
          <span class="sub">влияние ${num(o.influence)}</span></span>
        <span class="val">${chg}<small>было ${num(o.prevRank)}</small></span>
      </div>`;
    }).join('') || '<p class="empty">Нет данных по рейтингу.</p>';
  }

  // ---------- вкладки и события ----------
  function show(tab) {
    state.tab = tab;
    for (const b of document.querySelectorAll('.tab')) b.classList.toggle('on', b.dataset.tab === tab);
    for (const s of ['market', 'captures', 'rating']) $('#tab-' + s).hidden = s !== tab;
    flash('');
    if (tab === 'market' && !state.loaded.market) loadMarket(false);
    if (tab === 'captures' && !state.loaded.captures) loadCaptures(false);
    if (tab === 'rating' && !state.loaded.rating) loadRating(false);
  }

  function refresh() {
    if (state.tab === 'market') loadMarket(true);
    if (state.tab === 'captures') loadCaptures(true);
    if (state.tab === 'rating') loadRating(true);
  }

  function init() {
    const savedServer = localStorage.getItem('majestic.server');
    if (savedServer) $('#server').value = savedServer;

    renderKinds();
    renderPeriods();

    document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => show(b.dataset.tab)));
    $('#refresh').addEventListener('click', refresh);

    $('#server').addEventListener('change', () => {
      const s = server();
      $('#server').value = s;
      localStorage.setItem('majestic.server', s);
      state.loaded = { market: false, captures: false, rating: false };
      show(state.tab);
    });

    $('#kinds').addEventListener('click', (e) => {
      const b = e.target.closest('[data-kind]');
      if (!b) return;
      state.kind = b.dataset.kind;
      renderKinds();
      $('#m-result').innerHTML = '';
      loadMarket(false);
    });
    $('#m-name').addEventListener('input', renderList);
    $('#m-go').addEventListener('click', compare);
    $('#m-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') compare(); });
    $('#m-price').addEventListener('keydown', (e) => { if (e.key === 'Enter') compare(); });
    $('#m-list').addEventListener('click', (e) => {
      const b = e.target.closest('[data-name]');
      if (!b) return;
      $('#m-name').value = b.dataset.name;
      renderList();
      compare();
    });

    $('#c-go').addEventListener('click', () => loadCaptures(false));
    $('#c-family').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadCaptures(false); });
    $('#c-all').addEventListener('click', () => { $('#c-family').value = ''; loadCaptures(false); });
    $('#c-list').addEventListener('click', (e) => {
      const b = e.target.closest('[data-war]');
      if (b) togglePlayers(b.dataset.war);
    });
    $('#c-more').addEventListener('click', (e) => {
      if (e.target.id !== 'c-more-btn') return;
      state.warsShown += 100;
      renderWars();
    });

    $('#periods').addEventListener('click', (e) => {
      const b = e.target.closest('[data-period]');
      if (!b) return;
      state.period = b.dataset.period;
      renderPeriods();
      loadRating(false);
    });
    $('#r-filter').addEventListener('input', renderRating);

    show('market');
  }

  init();
})();
