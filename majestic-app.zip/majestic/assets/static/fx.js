/* Курсор-кружок вместо системного: кольцо + точка, эффект нажатия и волна. Только для мыши. */
(function () {
  if (!matchMedia('(pointer: fine)').matches || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var root = document.documentElement;
  root.classList.add('fx');                       // прячет системный курсор

  function make(cls) {
    var d = document.createElement('div');
    d.className = cls; d.setAttribute('aria-hidden', 'true');
    document.body.appendChild(d);
    return d;
  }
  var ring = make('cursor'), dot = make('cursor-dot');
  var x = 0, y = 0, rx = 0, ry = 0, raf = 0, off = false;

  function tick() {
    rx += (x - rx) * 0.28; ry += (y - ry) * 0.28;
    ring.style.transform = 'translate3d(' + rx + 'px,' + ry + 'px,0) translate(-50%,-50%)';
    raf = (Math.abs(x - rx) + Math.abs(y - ry) > 0.1) ? requestAnimationFrame(tick) : 0;
  }
  function move(e) {
    if (off) return;
    if (!ring.classList.contains('on')) { rx = x = e.clientX; ry = y = e.clientY; }
    x = e.clientX; y = e.clientY;
    root.style.setProperty('--mx', x + 'px');
    root.style.setProperty('--my', y + 'px');
    dot.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0) translate(-50%,-50%)';
    ring.classList.add('on'); dot.classList.add('on');
    if (!raf) raf = requestAnimationFrame(tick);
  }
  function ripple(px, py) {
    var r = make('ripple');
    r.style.left = px + 'px'; r.style.top = py + 'px';
    r.addEventListener('animationend', function () { r.remove(); });
  }
  function release() { ring.classList.remove('down'); dot.classList.remove('down'); }

  addEventListener('pointermove', move, { passive: true });
  addEventListener('pointerdown', function (e) {
    if (off || e.button > 0) return;
    move(e);
    ring.classList.add('down'); dot.classList.add('down');
    ripple(e.clientX, e.clientY);
  });
  addEventListener('pointerup', release);
  addEventListener('pointercancel', release);
  document.addEventListener('pointerover', function (e) {
    ring.classList.toggle('hot', !!(e.target.closest && e.target.closest('a, button, .project:not(.soon)')));
  });
  root.addEventListener('mouseleave', function () { ring.classList.remove('on'); dot.classList.remove('on'); });

  // Нельзя выделять и перетаскивать
  document.addEventListener('selectstart', function (e) { e.preventDefault(); });
  document.addEventListener('dragstart', function (e) { e.preventDefault(); });

  // Когда запускается проект, возвращаем системный курсор (игре он нужен)
  window.__fxOff = function () {
    off = true; release();
    ring.classList.remove('on', 'hot'); dot.classList.remove('on');
    root.classList.remove('fx');
  };
})();
