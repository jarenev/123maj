//! Действия интерфейса: разбор запроса JSON, обращение к API, нормализация ответов.
//!
//! Все публичные функции возвращают строку JSON вида
//! `{"ok":true,"data":...}` или `{"ok":false,"error":"..."}`.

use crate::api::{ApiError, Client};
use serde_json::{json, Map, Value};

/// Разделы маркетплейса: (ключ в URL, ключ массива в ответе).
pub const MARKET_KINDS: &[(&str, &str)] = &[
    ("vehicles", "vehicleStatistics"),
    ("items", "itemStatistics"),
    ("houses", "houseStatistics"),
    ("apartments", "apartmentStatistics"),
    ("warehouses", "warehouseStatistics"),
    ("offices", "officeStatistics"),
    ("clothes", "clothesStatistics"),
];

pub const RATING_PERIODS: &[&str] = &["", "week", "period", "season"];

/// Точка входа: строка запроса -> строка ответа. Никогда не паникует на вводе пользователя.
pub fn handle(client: &Client, input: &str) -> String {
    let result = match serde_json::from_str::<Value>(input) {
        Ok(req) => dispatch(client, &req),
        Err(_) => Err(ApiError("Некорректный запрос к ядру".into())),
    };
    match result {
        Ok(data) => json!({ "ok": true, "data": data }).to_string(),
        Err(e) => json!({ "ok": false, "error": e.0 }).to_string(),
    }
}

fn dispatch(c: &Client, req: &Value) -> Result<Value, ApiError> {
    let force = req.get("force").and_then(Value::as_bool).unwrap_or(false);
    let server = server_id(req)?;
    match req.get("action").and_then(Value::as_str).unwrap_or("") {
        "marketplace" => {
            let kind = market_kind(req)?;
            let body = c.get(&format!("/v1/ext/marketplace/{kind}/{server}"), force)?;
            Ok(market_data(kind, &body))
        }
        "compare" => {
            let kind = market_kind(req)?;
            let name = req.get("name").and_then(Value::as_str).unwrap_or("").trim();
            if name.is_empty() || name.chars().count() > 80 {
                return Err(ApiError("Введите название предмета (до 80 символов)".into()));
            }
            let price = parse_price(req.get("price"))?;
            let body = c.get(&format!("/v1/ext/marketplace/{kind}/{server}"), force)?;
            Ok(compare_data(&market_data(kind, &body), name, price))
        }
        "captures" => {
            let body = c.get(&format!("/v1/ext/captures/{server}"), force)?;
            Ok(captures_data(&body))
        }
        "wars" => {
            let family = req.get("family").and_then(Value::as_str).unwrap_or("").trim();
            if family.chars().count() > 64 {
                return Err(ApiError("Название фамы слишком длинное".into()));
            }
            let body = c.get(&format!("/v1/ext/family-wars/{server}"), force)?;
            Ok(wars_data(&body, family))
        }
        "rating" => {
            let period = req.get("period").and_then(Value::as_str).unwrap_or("");
            if !RATING_PERIODS.contains(&period) {
                return Err(ApiError("Неизвестный период рейтинга".into()));
            }
            let path = if period.is_empty() {
                format!("/v1/ext/rating-organizations/{server}")
            } else {
                format!("/v1/ext/rating-organizations/{server}?period={period}")
            };
            let body = c.get(&path, force)?;
            Ok(rating_data(&body))
        }
        _ => Err(ApiError("Неизвестное действие".into())),
    }
}

/// serverId попадает в URL, поэтому принимаем только безопасные символы.
fn server_id(req: &Value) -> Result<String, ApiError> {
    let s = req.get("server").and_then(Value::as_str).unwrap_or("RU1").trim();
    let ok = !s.is_empty()
        && s.len() <= 16
        && s.chars().all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-');
    if ok {
        Ok(s.to_string())
    } else {
        Err(ApiError("Некорректный ID сервера (например RU1)".into()))
    }
}

fn market_kind(req: &Value) -> Result<&'static str, ApiError> {
    let k = req.get("kind").and_then(Value::as_str).unwrap_or("");
    MARKET_KINDS
        .iter()
        .find(|(key, _)| *key == k)
        .map(|(key, _)| *key)
        .ok_or_else(|| ApiError("Неизвестный раздел маркетплейса".into()))
}

/// Цена приходит числом или строкой с пробелами («250 000»). Пусто — без сравнения.
fn parse_price(v: Option<&Value>) -> Result<Option<f64>, ApiError> {
    let raw = match v {
        None | Some(Value::Null) => return Ok(None),
        Some(Value::Number(n)) => n.as_f64().unwrap_or(f64::NAN),
        Some(Value::String(s)) => {
            let cleaned: String = s.chars().filter(|c| !c.is_whitespace() && *c != '$' && *c != ',').collect();
            if cleaned.is_empty() {
                return Ok(None);
            }
            cleaned.parse::<f64>().unwrap_or(f64::NAN)
        }
        _ => f64::NAN,
    };
    if raw.is_finite() && raw >= 0.0 {
        Ok(Some(raw))
    } else {
        Err(ApiError("Цена должна быть неотрицательным числом".into()))
    }
}

// ---------- helpers ----------

fn text(v: &Value, key: &str) -> Option<String> {
    v.get(key).and_then(|x| match x {
        Value::String(s) => Some(s.clone()),
        Value::Number(n) => Some(n.to_string()),
        _ => None,
    })
}

fn num(v: &Value, key: &str) -> Option<f64> {
    v.get(key).and_then(|x| match x {
        Value::Number(n) => n.as_f64(),
        Value::String(s) => s.trim().replace(' ', "").parse::<f64>().ok(),
        _ => None,
    })
}

fn raw(v: &Value, key: &str) -> Value {
    v.get(key).cloned().unwrap_or(Value::Null)
}

fn round1(x: f64) -> f64 {
    (x * 10.0).round() / 10.0
}

// ---------- маркетплейс ----------

/// Единый вид строки статистики для всех разделов маркетплейса.
pub fn market_data(kind: &str, body: &Value) -> Value {
    let key = MARKET_KINDS
        .iter()
        .find(|(k, _)| *k == kind)
        .map(|(_, arr)| *arr)
        .unwrap_or("");
    let rows: Vec<Value> = body
        .get(key)
        .and_then(Value::as_array)
        .map(|arr| arr.iter().map(|r| market_row(kind, r)).collect())
        .unwrap_or_default();

    json!({
        "kind": kind,
        "serverName": text(body, "serverName"),
        "lastUpdated": text(body, "lastUpdated"),
        "periodDays": raw(body, "periodDays"),
        "totalSold": raw(body, "totalSold"),
        "overallAveragePrice": raw(body, "overallAveragePrice"),
        "rows": rows,
    })
}

fn market_row(kind: &str, r: &Value) -> Value {
    let name = text(r, "itemName")
        .or_else(|| text(r, "modelName"))
        .unwrap_or_else(|| "—".into());
    let sub = match kind {
        "vehicles" => text(r, "model"),
        "items" => text(r, "itemId").map(|id| format!("id {id}")),
        "houses" => text(r, "houseId").map(|id| format!("дом {id}")),
        "apartments" => text(r, "apartmentId").map(|id| format!("квартира {id}")),
        "warehouses" => text(r, "warehouseId").map(|id| format!("склад {id}")),
        "offices" => text(r, "officeId").map(|id| format!("офис {id}")),
        "clothes" => Some(format!(
            "компонент {} · drawable {} · texture {}",
            text(r, "component").unwrap_or_default(),
            text(r, "drawable").unwrap_or_default(),
            text(r, "texture").unwrap_or_default()
        )),
        _ => None,
    };
    json!({
        "name": name,
        "sub": sub,
        "sold": raw(r, "soldCount"),
        "total": raw(r, "totalCount"),
        "avg": raw(r, "averagePrice"),
        "min": raw(r, "minPrice"),
        "max": raw(r, "maxPrice"),
    })
}

/// Сравнение: находит все строки с этим названием и считает сводку по ним.
/// Если совпадений несколько (например, одежда с разными drawable), средняя взвешена по продажам.
pub fn compare_data(market: &Value, name: &str, price: Option<f64>) -> Value {
    let rows = market.get("rows").and_then(Value::as_array).cloned().unwrap_or_default();
    let needle = name.to_lowercase();

    let mut matches: Vec<Value> = rows
        .iter()
        .filter(|r| text(r, "name").map(|n| n.to_lowercase() == needle).unwrap_or(false))
        .cloned()
        .collect();
    if matches.is_empty() {
        matches = rows
            .iter()
            .filter(|r| text(r, "name").map(|n| n.to_lowercase().contains(&needle)).unwrap_or(false))
            .cloned()
            .collect();
    }

    if matches.is_empty() {
        return json!({ "market": market_meta(market), "found": false, "matches": [], "summary": null, "verdict": null });
    }

    let mut sold_total = 0.0;
    let mut weighted = 0.0;
    let mut plain = Vec::new();
    let mut min: Option<f64> = None;
    let mut max: Option<f64> = None;
    for m in &matches {
        let sold = num(m, "sold").unwrap_or(0.0);
        if let Some(avg) = num(m, "avg") {
            sold_total += sold;
            weighted += avg * sold;
            plain.push(avg);
        }
        if let Some(lo) = num(m, "min") {
            min = Some(min.map_or(lo, |x| x.min(lo)));
        }
        if let Some(hi) = num(m, "max") {
            max = Some(max.map_or(hi, |x| x.max(hi)));
        }
    }
    let avg = if sold_total > 0.0 {
        Some(weighted / sold_total)
    } else if !plain.is_empty() {
        Some(plain.iter().sum::<f64>() / plain.len() as f64)
    } else {
        None
    };

    let verdict = match (price, avg, min, max) {
        (Some(p), Some(a), Some(lo), Some(hi)) => {
            let (position, percent) = if p < lo {
                ("below_min", None)
            } else if p > hi {
                ("above_max", None)
            } else if p < a {
                ("below_avg", Some(round1((a - p) / a * 100.0)))
            } else {
                ("above_avg", Some(round1((p - a) / a * 100.0)))
            };
            json!({ "position": position, "percent": percent, "price": p })
        }
        _ => Value::Null,
    };

    json!({
        "market": market_meta(market),
        "found": true,
        "matches": matches,
        "summary": {
            "name": text(&matches[0], "name"),
            "sold": sold_total,
            "avg": avg,
            "min": min,
            "max": max,
        },
        "verdict": verdict,
    })
}

fn market_meta(market: &Value) -> Value {
    json!({
        "serverName": market.get("serverName").cloned().unwrap_or(Value::Null),
        "lastUpdated": market.get("lastUpdated").cloned().unwrap_or(Value::Null),
        "periodDays": market.get("periodDays").cloned().unwrap_or(Value::Null),
    })
}

// ---------- капты ----------

/// Текущие владельцы капт. controlStartTime в секундах -> в миллисекундах для JS.
pub fn captures_data(body: &Value) -> Value {
    let zones: Vec<Value> = body
        .get("zones")
        .and_then(Value::as_array)
        .map(|arr| {
            arr.iter()
                .map(|z| {
                    json!({
                        "zoneId": raw(z, "zoneId"),
                        "familyId": raw(z, "familyId"),
                        "family": text(z, "familyName"),
                        "tag": text(z, "familyTag"),
                        "color": text(z, "familyMainColor"),
                        "sinceMs": num(z, "controlStartTime").map(|s| s * 1000.0),
                    })
                })
                .collect()
        })
        .unwrap_or_default();
    json!({
        "serverName": text(body, "serverName"),
        "lastUpdated": text(body, "lastUpdated"),
        "zones": zones,
    })
}

/// История войн за капты. `family` — фильтр по названию любой из сторон (пусто = все).
pub fn wars_data(body: &Value, family: &str) -> Value {
    let needle = family.to_lowercase();
    let list = body.get("captures").and_then(Value::as_array).cloned().unwrap_or_default();

    let mut wars: Vec<Value> = list
        .iter()
        .filter_map(|w| {
            let def_name = text(w, "defendersName").unwrap_or_default();
            let att_name = text(w, "attackersName").unwrap_or_default();
            if !needle.is_empty()
                && !def_name.to_lowercase().contains(&needle)
                && !att_name.to_lowercase().contains(&needle)
            {
                return None;
            }
            let def_id = num(w, "defendersId").map(|x| x as i64);
            let att_id = num(w, "attackersId").map(|x| x as i64);
            let winner = match num(w, "winner").map(|x| x as i64) {
                Some(id) if Some(id) == att_id => json!("attack"),
                Some(id) if Some(id) == def_id => json!("defense"),
                _ => Value::Null,
            };
            Some(json!({
                "id": raw(w, "id"),
                "captureId": raw(w, "captureId"),
                "zoneId": raw(w, "gangZoneId"),
                "map": text(w, "selectedMapName"),
                "status": text(w, "status"),
                "startAt": text(w, "startAt"),
                "endAt": text(w, "endAt"),
                "defender": { "id": def_id, "name": def_name },
                "attacker": { "id": att_id, "name": att_name },
                "winner": winner,
                "ratings": { "defender": raw(w, "defenderRating"), "attacker": raw(w, "attackerRating") },
                "uniqueDefenders": raw(w, "uniqueDefenders"),
                "uniqueAttackers": raw(w, "uniqueAttackers"),
                "players": players_of(w, def_id, att_id),
            }))
        })
        .collect();

    // Свежие войны сверху. startAt — ISO-строка, её можно сравнивать лексикографически.
    wars.sort_by(|a, b| {
        let sa = a.get("startAt").and_then(Value::as_str).unwrap_or("");
        let sb = b.get("startAt").and_then(Value::as_str).unwrap_or("");
        sb.cmp(sa)
    });

    json!({
        "serverName": text(body, "serverName"),
        "family": family,
        "count": wars.len(),
        "wars": wars,
    })
}

/// players: {"<familyId>": [ {id,name,familyName,kills,damage} ]} -> плоский список со стороной.
fn players_of(w: &Value, def_id: Option<i64>, att_id: Option<i64>) -> Value {
    let mut out: Vec<Value> = Vec::new();
    if let Some(map) = w.get("players").and_then(Value::as_object) {
        for (key, arr) in map {
            let key_id = key.parse::<i64>().ok();
            let side = if key_id.is_some() && key_id == def_id {
                "defense"
            } else if key_id.is_some() && key_id == att_id {
                "attack"
            } else {
                "unknown"
            };
            if let Some(list) = arr.as_array() {
                for p in list {
                    let mut obj = Map::new();
                    obj.insert("side".into(), json!(side));
                    obj.insert("name".into(), json!(text(p, "name")));
                    obj.insert("family".into(), json!(text(p, "familyName")));
                    obj.insert("kills".into(), raw(p, "kills"));
                    obj.insert("damage".into(), raw(p, "damage"));
                    out.push(Value::Object(obj));
                }
            }
        }
    }
    out.sort_by(|a, b| {
        let da = num(a, "damage").unwrap_or(0.0);
        let db = num(b, "damage").unwrap_or(0.0);
        db.partial_cmp(&da).unwrap_or(std::cmp::Ordering::Equal)
    });
    Value::Array(out)
}

// ---------- рейтинг ----------

pub fn rating_data(body: &Value) -> Value {
    let mut orgs: Vec<Value> = body
        .get("organizations")
        .and_then(Value::as_array)
        .map(|arr| {
            arr.iter()
                .map(|o| {
                    let rank = num(o, "rank");
                    let prev = num(o, "prevRank");
                    // change > 0 — поднялась, < 0 — опустилась, null — нет данных о прошлом месте
                    let change = match (prev, rank) {
                        (Some(p), Some(r)) => json!(p - r),
                        _ => Value::Null,
                    };
                    json!({
                        "rank": raw(o, "rank"),
                        "prevRank": raw(o, "prevRank"),
                        "change": change,
                        "familyId": raw(o, "familyId"),
                        "name": text(o, "name"),
                        "tag": text(o, "tag"),
                        "influence": num(o, "influence"),
                        "color": text(o, "mainColor"),
                    })
                })
                .collect()
        })
        .unwrap_or_default();
    orgs.sort_by(|a, b| {
        let ra = num(a, "rank").unwrap_or(f64::MAX);
        let rb = num(b, "rank").unwrap_or(f64::MAX);
        ra.partial_cmp(&rb).unwrap_or(std::cmp::Ordering::Equal)
    });
    json!({
        "serverName": text(body, "serverName"),
        "organizations": orgs,
    })
}
