//! Majestic: клиент API маджестика для Android.
//!
//! Ядро (HTTP, лимит 5 запросов / 60 с, кэш, разбор ответов) написано на Rust.
//! Интерфейс — HTML в APK, он вызывает ядро через мост `Android.call`
//! и JNI-функцию `Java_com_majestic_app_Core_request`.

pub mod api;
pub mod ops;

#[cfg(target_os = "android")]
mod jni_bridge {
    use jni::objects::{JClass, JString};
    use jni::sys::jstring;
    use jni::JNIEnv;

    #[no_mangle]
    pub extern "system" fn Java_com_majestic_app_Core_request<'l>(
        mut env: JNIEnv<'l>,
        _class: JClass<'l>,
        input: JString<'l>,
    ) -> jstring {
        let text: String = env.get_string(&input).map(|s| s.into()).unwrap_or_default();
        let out = crate::ops::handle(crate::api::global(), &text);
        match env.new_string(out) {
            Ok(s) => s.into_raw(),
            Err(_) => std::ptr::null_mut(),
        }
    }
}
