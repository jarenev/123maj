//! HTTP-клиент к api.majestic-files.net: заголовок X-API-KEY, лимит 5 запросов / 60 с, кэш.

use serde_json::Value;
use std::collections::{HashMap, VecDeque};
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};

pub const BASE_URL: &str = "https://api.majestic-files.net";

/// Ключ вшивается в сборку: `MAJESTIC_API_KEY=... cargo build ...`.
pub const API_KEY: &str = match option_env!("MAJESTIC_API_KEY") {
    Some(k) => k,
    None => "",
};

const RATE_MAX: usize = 5;
const RATE_WINDOW: Duration = Duration::from_secs(60);
const CACHE_TTL: Duration = Duration::from_secs(300);

#[derive(Debug, Clone, PartialEq)]
pub struct ApiError(pub String);

pub struct Client {
    base: String,
    key: String,
    agent: ureq::Agent,
    hits: Mutex<VecDeque<Instant>>,
    cache: Mutex<HashMap<String, (Instant, Value)>>,
}

pub fn global() -> &'static Client {
    static CLIENT: OnceLock<Client> = OnceLock::new();
    CLIENT.get_or_init(|| Client::new(BASE_URL, API_KEY))
}

impl Client {
    pub fn new(base: &str, key: &str) -> Self {
        Client {
            base: base.trim_end_matches('/').to_string(),
            key: key.to_string(),
            agent: ureq::AgentBuilder::new()
                .timeout(Duration::from_secs(25))
                .build(),
            hits: Mutex::new(VecDeque::new()),
            cache: Mutex::new(HashMap::new()),
        }
    }

    /// GET `path` (вместе с query-строкой). `force` — игнорировать кэш.
    pub fn get(&self, path: &str, force: bool) -> Result<Value, ApiError> {
        if self.key.is_empty() {
            return Err(ApiError(
                "Ключ API не вшит в сборку. Соберите приложение с переменной MAJESTIC_API_KEY.".into(),
            ));
        }
        if !force {
            if let Some((t, v)) = self.cache.lock().unwrap().get(path) {
                if t.elapsed() < CACHE_TTL {
                    return Ok(v.clone());
                }
            }
        }
        self.wait_for_slot();

        let url = format!("{}{}", self.base, path);
        let response = self
            .agent
            .get(&url)
            .set("X-API-KEY", &self.key)
            .set("X-LANGUAGE", "ru")
            .set("Accept", "application/json")
            .call();

        let value: Value = match response {
            Ok(r) => r
                .into_json()
                .map_err(|_| ApiError("Сервер вернул ответ не в формате JSON".into()))?,
            Err(ureq::Error::Status(code, _)) => return Err(ApiError(status_message(code))),
            Err(ureq::Error::Transport(_)) => {
                return Err(ApiError("Нет связи с api.majestic-files.net".into()))
            }
        };
        self.cache
            .lock()
            .unwrap()
            .insert(path.to_string(), (Instant::now(), value.clone()));
        Ok(value)
    }

    /// Не более RATE_MAX запросов за RATE_WINDOW: при нехватке ждём освобождения слота.
    fn wait_for_slot(&self) {
        loop {
            let wait = {
                let mut hits = self.hits.lock().unwrap();
                let now = Instant::now();
                while let Some(&first) = hits.front() {
                    if now.duration_since(first) >= RATE_WINDOW {
                        hits.pop_front();
                    } else {
                        break;
                    }
                }
                if hits.len() < RATE_MAX {
                    hits.push_back(now);
                    return;
                }
                let first = *hits.front().unwrap();
                RATE_WINDOW.saturating_sub(now.duration_since(first))
            };
            std::thread::sleep(wait + Duration::from_millis(50));
        }
    }
}

pub fn status_message(code: u16) -> String {
    match code {
        401 => "Ключ API не принят сервером (401)".into(),
        403 => "Для этого ключа нет доступа к API (403)".into(),
        429 => "Превышен лимит запросов: 5 за 60 секунд (429)".into(),
        500 => "Внутренняя ошибка сервера Majestic (500)".into(),
        other => format!("Ошибка HTTP {other}"),
    }
}
