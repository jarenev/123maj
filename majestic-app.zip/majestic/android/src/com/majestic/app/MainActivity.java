package com.majestic.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/**
 * Оболочка: WebView с интерфейсом из assets, мост к Rust-ядру.
 * JS вызывает Android.call(id, json); ответ приходит в window.__resolve(id, json).
 */
public class MainActivity extends Activity {
    private static final String TAG = "Majestic";
    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        Window w = getWindow();
        w.setStatusBarColor(0xFF000000);
        w.setNavigationBarColor(0xFF000000);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // запоминаем сервер между запусками
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setBackgroundColor(0xFF000000);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Внешние ссылки не открываем: интерфейс целиком внутри приложения.
                return !url.startsWith("file:///android_asset/");
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }

    /** Методы моста. Вызываются из потока WebView, тяжёлая работа уходит в отдельный поток. */
    final class Bridge {
        @JavascriptInterface
        public void call(final String id, final String json) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String result;
                    try {
                        result = Core.request(json);
                    } catch (Throwable t) {
                        Log.e(TAG, "native error", t);
                        result = "{\"ok\":false,\"error\":\"Ошибка ядра приложения\"}";
                    }
                    final String payload = result;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript(
                                    "window.__resolve(" + JSONObject.quote(id) + "," + JSONObject.quote(payload) + ")",
                                    null);
                        }
                    });
                }
            }, "majestic-request").start();
        }
    }
}
