package com.majestic.app;

/** Мост к Rust-ядру (libmajestic.so). Метод реализован в src/lib.rs. */
final class Core {
    static {
        System.loadLibrary("majestic");
    }

    private Core() {}

    /** JSON-запрос -> JSON-ответ. Вызывается не из UI-потока. */
    static native String request(String json);
}
